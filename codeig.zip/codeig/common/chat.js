$(document).ready(function() {
    alert('hi');
});