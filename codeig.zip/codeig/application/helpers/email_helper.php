<?php
function send_mail($to_email, $subject, $msg)
{
	// load values from config
	$CI =& get_instance();
	$CI->load->library('email');
	$CI->config->load('email');
	$from_email = $CI->config->item('from_email');
	$from_name = $CI->config->item('from_name');
	$subject = $CI->config->item('subject_prefix').$subject;

	// basic parameters
	$CI->email->from($from_email, $from_name);
	$CI->email->to($to_email);
	$CI->email->subject($subject);
	//$CI->email->cc($from_email, $from_name);
	//$CI->email->reply_to($from_email, $from_name);
	
	// confirm to send
	$CI->email->message($msg);
	$CI->email->send();

	//echo $CI->email->print_debugger();
}
?>