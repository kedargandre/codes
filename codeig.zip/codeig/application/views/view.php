<html>
<body>
<div class="main">
	<div id="content">
		<h3 id='form_head'>Codelgniter Pagination Example </h3><br/>
		
				<div id="form_input">
					<?php
						echo $this->pagination->create_links();
					?>
					
				</div>
							</div>
	</div>
</div>
</body>
</html>


