<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html >

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Upload Files to Amazon S3 PHP</title>
</head>

<body>
    <form action="upload" method='post' enctype="multipart/form-data">
        <h3>Upload image file here</h3>
        <br/>
        <div style='margin:10px'>
            <input type='file' name='file' />
            <input type='submit' value='Upload Image' />
        </div>
    </form>
    <form action="hotel_upload" method='post' enctype="multipart/form-data">
        <h3>Upload hotel image and json</h3>
        <br/>
        <div style='margin:10px'>
            <input type='file' name='file' />
            <input type='submit' value='Upload Image' />
        </div>
    </form>
</body>

</html>