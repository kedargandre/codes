<?php 
echo $msg."<br>";
if (isset($path) && !empty($path)) 
{
	echo "URL is : <br>".$path;
}
?>