<h1>This is chat</h1>

<div id='chat_input'>
	<input type='text' id='chat_message' name='chat_message'>
	<input type='button' id='submit_message' name='submit_message' value='Send'>
	
</div>
<script src="https://code.jquery.com/jquery-1.11.3.js"></script>
<script type="text/javascript" >
	$(document).ready(function() {
	    // alert('hi');
	    $('#submit_message').click(function(){
	    	alert($('input#chat_message').val());
	    	return false;
	    });

	});
</script>