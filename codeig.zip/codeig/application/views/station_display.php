<html>
<head>
<title>Location</title>
</head>
<body>

	<?php
	//echo "<pre>";print_r($result);exit;
	?>
		<select name='color'>
	<?php
	foreach($result as $key => $value)
	{
		?>
			<option value = <?php  $value['station_name']?> > <?php echo $value['station_name']?> </option>

		<?php
		
	}
	?>
		</select> 



</body>
</html>
