<?php
class Calendar extends CI_Controller 
{
	function __construct()
	{
		parent::__construct();

		// $this->load->library('calendar');
	}

	public function show_cal($year = NULL, $month = NULL)
	{
		$pref = array(
	        'show_next_prev'       	=> 'TRUE',
	        'next_prev_url'       	=> base_url().'calendar/show_cal'
	    );

		$events = array(

			(int)'01' 	=> 'rent1',
			(int)'04' 	=> 'rent2',
			(int)'10' 	=> 'rent3',
			(int)'10' 	=> 'rent3',
			'15'		=> 'pay bill'
		);

	    $this->load->library('calendar', $pref);

	   	$data['title'] = 'mycal';
	   	
	    echo $this->calendar->generate($year, $month);
	}
	
}
?> 