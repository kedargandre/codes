<?php
class Welcome extends CI_Controller 
{
    public function __construct() {
        parent:: __construct();
        $this->load->helper("url");
        $this->load->model("Countries");
        $this->load->library("pagination");
    }

     public function index()
    {
        echo "hi";
    }

    /*public function example1() {
        $config = array();
        $config["base_url"] = base_url() . "welcome/example1";
        $config["total_rows"] = $this->Countries->record_count();
        $config["per_page"] = 20;
        $config["uri_segment"] = 3;

        $this->pagination->initialize($config);

        $page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
        $data["results"] = $this->Countries->
            fetch_countries($config["per_page"], $page);
        $data["links"] = $this->pagination->create_links();

        $this->load->view("example1", $data);
    }*/
    
    public function pagination()
    {
        if($this->uri->segment(3)){
            $start = $this->uri->segment(3);
        }
        if(empty($start)){
            $start = 0;
        }
        $this->load->library("pagination");
        $perpage = 5;
        //$start = 1;

        $data['ress'] = array('a1','b2','n3','m4','a5','s6','d7','f8','g9','h0','j11','k12','l13','p14','o15','i16','u17','y18','t19','e20');
        $data['result'] = array_slice($data["ress"],$start,$perpage);
        $data['config']['base_url']= site_url('welcome/pagination/');
        $data['config']['uri_segment'] = 3;
        $data['config']['total_rows']=  count($data['ress']);
        $data['config']['per_page']=$perpage;
        //$data['current_page']=$page;
        $this->pagination->initialize($data['config']);
        //$data['pagination'] = $this->pagination->create_links();  
        //echo $this->uri->segment(2);
        //$this->load->view('bus/pagination', $data);
        $this->load->view('welcome_message', $data);
    }

    public function pagination2()
    {
        $offset = ($this->uri->segment(4) != '' ? $this->uri->segment(4): 0);
            
        $this->data['requests']     = $this->Backend_model->get_registration_requests();

        $config['total_rows']       = count($this->data['requests']);
        $config['per_page']         = 10;
        $config['base_url']         = base_url()."admin/welcome/pagination2/"; 
        
        $this->pagination->initialize($config);

        $this->data['count']      = ($this->uri->segment(4) != "" ? $this->uri->segment(4) : '0') + 1;
        $this->data['start']      = $offset;
        $this->data['offset']     = $config['per_page'];

        //VIEW
        $requests = array_slice($requests, $start, $offset);
        foreach ($requests as $request):?>
        <tr class="text-center">
            <td><?php echo $count; ?></td><!-- Serial number -->
            <td><?php echo $request['email']; ?></td>
            <td><?php echo date("d-M-Y h:i A", strtotime($request['requested_on'])); ?></td>
        </tr>
        <?php $count = $count + 1;
        endforeach;
    }

    public function database()
    {
        //load common model

        $condition = array("id" => $_GET['pid']);
        $parent_data = $this->Backend_model->select(DbTable::TABLE_MENU, $condition);

        $save_result = $this->Backend_model->create(DbTable::TABLE_MENU, $save_data);

        $condition = array('id' => $id);
        $update_result = $this->Backend_model->update(DbTable::TABLE_MENU, $condition, $update_data);
    }

    public function alerts()
    {
        //load alert library

        set_alert("success", "Data updated successfully");
        set_alert("danger", "Data not updated");


        // to get alert
        echo get_alert();
    }

    public function to_send_mail()
    {
        //load helper and config

        send_mail("email id", "subject", "message");
    }

    public function upload_file()
    {
        $directory_path = UPLOAD_PATH;

        $directoty_path_array   = array('uploads', 'images', $this->vendor_id, 'cover_images');

        foreach ($directoty_path_array as $key => $value) 
        {
            $directory_path = $directory_path.$value.'/';
            if (!is_dir($directory_path)) 
            {
                mkdir($directory_path,0777);
            }
        }

        $upload_response = $this->upload_file->upload_image($_FILES['profile_image_input']['name'], $directory_path);

        if($upload_response != '1')
        {
            throw new Exception($upload_response, 1);
        }
        else
        {
            $upload_file_data       = $this->upload->data();
            $upload_file_name       = $upload_file_data['file_name'];
            $cover_image_full_path  = $directory_path.$upload_file_name;
        }
    }
}

?>