<?php
class s3_upload extends CI_Controller 
{
	function __construct()
	{
		parent::__construct();
		$this->load->library('S3');

	}
	public function index()
	{
		$this->load->view('s3_view/s3_view');
	}
	function upload() //for single image upload
	{
		$msg='';
		$valid_formats = array("jpg", "png", "gif", "bmp","jpeg","PNG","JPG","JPEG","GIF","BMP","json");
		if($_SERVER['REQUEST_METHOD'] == "POST")
		{
			$name = $_FILES['file']['name'];
			$size = $_FILES['file']['size'];
			$tmp = $_FILES['file']['tmp_name'];
			$ext = $this->getExtension($name);

			if(strlen($name) > 0)
			{
				if(in_array($ext,$valid_formats))
				{
					if($size<(1024*1024))
					{
						$bucket  = $this->config->item('bucket').".img";

						$s3 = new S3($this->config->item('access_key'), $this->config->item('secret_key'));
						$s3->putBucket($bucket, S3::ACL_PUBLIC_READ); 

						$actual_image_name = time().".".$ext;

						if($s3->putObjectFile($tmp, $bucket , $actual_image_name, S3::ACL_PUBLIC_READ) )
						{
							$msg = "S3 Upload Successful.";	
							$s3file='http://'.$bucket.'.s3.amazonaws.com/'.$actual_image_name;
							$data['path'] = $s3file;
						}
						else
							$msg = "S3 Upload Fail.";
					}
					else
						$msg = "Image size Max 1 MB";
				}
				else
					$msg = "Invalid file, please upload image file.";
			}
			else
				$msg = "Please select image file.";
		}

		$data['msg'] = $msg;
		$this->load->view('s3_view/s3_result',$data);
	}
	function getExtension($str) 
	{
     	$i = strrpos($str,".");
     	if (!$i) { return ""; } 

     	$l = strlen($str) - $i;
     	$ext = substr($str,$i+1,$l);
     	return $ext;
	}
	// for hotel
	function hotel_upload() 
	{
    	$this->json();
    	echo "<pre>";print_r($this->data);exit;
    	$this->imgdown();
		$this->into_database($this->data);
	}
	function upload_all_image($path,$name,$code,$resolution) //upload multiple
	{
		$ext = $this->getExtension($name);
		$bucket  = "img".".".$resolution.".".$code;

		$s3 = new S3($this->config->item('access_key'), $this->config->item('secret_key'));
		$s3->putBucket($bucket, S3::ACL_PUBLIC_READ); 

		if($s3->putObjectFile($path, $bucket , $name, S3::ACL_PUBLIC_READ) )
		{
			$msg = "S3 Upload Successful.";	
			$s3file='http://'.$bucket.'.s3.amazonaws.com/'.$name;
			$this->data[$code][$resolution] = $s3file;
		}
	}
	function upload_json($path,$code) //upload multiple
	{
		$bucket  = "json".".".$code;
		$path =  $code.".json";
		$s3 = new S3($this->config->item('access_key'), $this->config->item('secret_key'));
		$s3->putBucket($bucket, S3::ACL_PUBLIC_READ); 

		if($s3->putObjectFile($path, $bucket , $path, S3::ACL_PUBLIC_READ) )
		{
			$msg = "S3 Upload Successful.";	
			$s3file='http://'.$bucket.'.s3.amazonaws.com/'.$code;
			$this->data[$code]["json"] = $s3file;
		}
	}
	function into_database($data)
	{
		$servername = "192.168.5.200";
		$username = "root";
		$password = "admin1234";
		$dbname = "pace_api";

		$conn = new mysqli($servername, $username, $password, $dbname);

		if ($conn->connect_error) {
		    die("Connection failed: " . $conn->connect_error);
		} 
		foreach ($data as $key => $value) 
		{
			$sql = "SELECT hotel_code FROM tbl_domestic_hotel_s3_img_url WHERE hotel_code = '".$hotel_code."'";
			$result = $conn->query($sql);
			if ($result->num_rows > 0) 
			{
				$sql = "UPDATE tbl_domestic_hotel_s3_img_url SET ".$resolution." = '".$s3file."' WHERE hotel_code = '".$hotel_code."'";

				if ($conn->query($sql) === TRUE) {
				    echo "New record created successfully for".$resolution;
				} else {
				    echo "Error: " . $sql . "<br>" . $conn->error;
				}
			} 
			else 
			{
			    $sql = "INSERT INTO tbl_domestic_hotel_s3_img_url (hotel_code, $resolution)
					VALUES ('".$hotel_code."', '".$s3file."')";
				if ($conn->query($sql) === TRUE) {
				    echo "New record created successfully for".$resolution;
				} else {
				    echo "Error: " . $sql . "<br>" . $conn->error;
				}
			}	
		}
	}
	function imgdown()
	{
		$user_name = "root";
	    $password = "admin1234";
	    $database = "pace_api";
	    $host = "192.168.5.200";

	    $connection = mysql_connect($host, $user_name, $password) or die ("ERROR: Cannot connect");
	    $db = mysql_select_db($database);
	    
	    $sql = "SELECT * FROM `tbl_domestic_hotel_img_url` WHERE `status` =1 LIMIT 10";
	    $result = mysql_query($sql) or die ("ERROR: " .mysql_error($connection) . " (query was $sql)");

	    while ($data = mysql_fetch_assoc($result)) 
	    {       
	        $id=1;
	        $url = $data['img_urls'];
	        $sql1 = "SELECT hotel_name FROM `tbl_domestic_hotel_details` WHERE hotel_id=".$id;
	        $result1 = mysql_query($sql1) or die ("ERROR: " .mysql_error($connection) . " (query was $sql1)");
	        $row1 = mysql_fetch_assoc($result1);
	        $name=$row1['hotel_name'];
	        $h_name=strtr(strtolower($name), array(' ' => '-', ',' => ''));
	        
	        $imgurl=json_decode($url,true); 
	        foreach ($imgurl as  $k => $v) 
	        {
	            $ext = pathinfo($v, PATHINFO_EXTENSION);
	            $image_size = array('125,125','166,114','127,87','275,190','373,343','245,159','380,246');    
	            foreach ($image_size as $imagkey => $imagvalue) 
	            {
	                $imageresize = explode(',', $imagvalue);
	                
	                $hotel_id = $id;    //hotel id
	                
	                $image_resolution = $imageresize[0].'x'.$imageresize[1] ;  //image resolution  
	                
	                $out_path = $id."-".$h_name."-".$k.".".$ext;   // image name

	                $this->createthumb($hotel_id,$v,$image_resolution,$out_path,$imageresize[0],$imageresize[1]);
	            }
	        }
	    } 
	}
	function createthumb($hotel_id,$name,$image_resolution,$filename,$new_w,$new_h)
	{
	    $ext2 = pathinfo($name, PATHINFO_EXTENSION);
	    if (preg_match("/jpg|jpeg/",$ext2))
	    {
	        $src_img=imagecreatefromjpeg($name);
	    }
	    if (preg_match("/png/",$ext2))
	    {
	        $src_img=imagecreatefrompng($name);
	    }
	    $old_x=imageSX($src_img);
	    $old_y=imageSY($src_img);
	    $thumb_w=$old_x;
	    $thumb_h=$old_y;
	    if ($old_x > $old_y) 
	    {
	        if($new_w<$old_x)
	        {
	            $thumb_w=$new_w;
	        }
	        if($new_h<$old_y)
	        {
	            $thumb_h=$old_y*($new_h/$old_x);
	        }
	    }

	    if ($old_x < $old_y) 
	    {
	        if($new_w<$old_x)
	        {
	            $thumb_w=$old_x*($new_w/$old_y);
	        }
	        if($new_h<$old_y)
	        {
	             $thumb_h=$new_h;
	        }
	    }
	    if ($old_x == $old_y) 
	    {
	        if($new_w<$old_x)
	        {
	            $thumb_w=$new_w;
	        }
	        if($new_h<$old_y)
	        {
	            $thumb_h=$new_h;
	        }
	    }
	    $qry = "select * from tbl_domestic_hotels_master limit 5";
	    $rs  = mysql_query($qry)or die(mysql_error());
	    $data = mysql_fetch_assoc($rs);

	    $dst_img=ImageCreateTrueColor($thumb_w,$thumb_h);
	    imagecopyresampled($dst_img,$src_img,0,0,0,0,$thumb_w,$thumb_h,$old_x,$old_y); 

	    $hotl_id_fold = dirname(__FILE__).'/'.$data['hotel_code'];
	    if (!is_dir($hotl_id_fold)) 
	    {
	        mkdir($hotl_id_fold,0777);
	    }
	    if (is_dir($hotl_id_fold)) 
	    {
	        $images = $hotl_id_fold.'/images'; 
	        if (!is_dir($images)) 
	        {
	             mkdir($images);
	        }
	    }
	    if (is_dir($images)) 
	    {
	        $hotel_image_resolution = $images."/".$image_resolution;

	        if (!is_dir($hotel_image_resolution)) 
	        {
	             mkdir($hotel_image_resolution);
	        }
	    }
	    $directory = $hotel_image_resolution.'/'.$filename;

	    if (preg_match("/png/",$ext2))
	    {
	        $newimg = imagepng($dst_img,$directory); 
	    } 
	    else 
	    {
	        $newimg = imagejpeg($dst_img,$directory); 
	    }      
	    $this->upload_all_image($directory,$filename,$data['hotel_code'],$image_resolution);
	}

	function json()
	{
		try
		{
			$con = mysql_connect("192.168.5.200","root","admin1234");
			$db =  mysql_select_db('pace_api',$con);
			$qry = "select * from tbl_domestic_hotels_master limit 5";
			$rs  = mysql_query($qry)or die(mysql_error());
			$i=0;
			$msg = "";
			while($row=mysql_fetch_assoc($rs))
			{
				$hotel_id = $row['hotel_code'];
				// $hotel_id = $row['id'];
				//$hotel_id = 1;
				 $amenity_qry = "SELECT * from tbl_domestic_hotel_amenities where hotel_id = ".$hotel_id;

				 $amenity_rs  = mysql_query($amenity_qry)or die(mysql_error());
				 
				 while($amenity = mysql_fetch_assoc($amenity_rs))
				 {
				 	$ids = json_decode($amenity['amenity_id'],true);
				
				 	$test =array();
				 	foreach($ids as $id)
				 	{        
				 		$amenity_desc = mysql_query("SELECT amenity_type,amenity_description from tbl_domestic_amenity WHERE id=". $id)or die(mysql_error());
				 		
				 		while($data = mysql_fetch_assoc($amenity_desc))
				 		{
				 			$test[$data['amenity_type']][$id] = $data['amenity_description'];
						}
				 	}
				 	$amenity_res=$test;
				 }
				
				 $landmark_qry = "SELECT * from tbl_domestic_hotel_near_by_places where hotel_id =".$hotel_id;
				 $landmark_rs  = mysql_query($landmark_qry)or die(mysql_error());
				 $landmark_res_name =array();
				 while($landmark = mysql_fetch_assoc($landmark_rs))
				 {
				 	$landmark_res_name[$landmark['id']]=$landmark['name_of_place'];
				 }

				 
				 $review_qry = "SELECT * from tbl_domestic_review where hotel_id =" .$hotel_id;
				 $review_rs  = mysql_query($review_qry)or die(mysql_error());
				 $reviews =array();
				 while($review = mysql_fetch_assoc($review_rs ))
				 {
				 	$reviews[$review['id']]=array('comment' => htmlentities($review['comment']),
			          'consumer_city' => $review['consumer_city'],
			          'consumer_city' => $review['consumer_city'],
			          'consumer_country' => $review['consumer_country'],
			          'consumer_name' => $review['consumer_name'],
			          'status' => $review['status']);
				 }

				 $image_qry = "SELECT * from tbl_domestic_hotel_img_url where hotel_id = ". $hotel_id;
				 $image_rs  = mysql_query($image_qry)or die(mysql_error());
				 while($image = mysql_fetch_assoc($image_rs))
				 {
				 	$images=$image['img_urls'];
				 }

				 $detail_qry = "SELECT * from tbl_domestic_hotel_details where hotel_id = ". $hotel_id;
				 $detail_rs  = mysql_query($detail_qry)or die(mysql_error());
				 while($hoteldetails = mysql_fetch_assoc($detail_rs))
				 {
				 	$hoteldetails_destination_id=$hoteldetails['destination_id'];
				 	$hoteldetails_hotel_name=$hoteldetails['hotel_name'];
				 	$hoteldetails_hotel_class=$hoteldetails['hotel_class'];
				 	$hoteldetails_hotel_address=$hoteldetails['hotel_address'];
				 	$hoteldetails_hotel_area=$hoteldetails['hotel_area'];
				 	$hoteldetails_hotel_overview=htmlentities($hoteldetails['hotel_overview']);
				 	$hoteldetails_review_rating=$hoteldetails['review_rating'];
				 	$hoteldetails_latitude=$hoteldetails['latitude'];
				 	$hoteldetails_longitude=$hoteldetails['longitude'];
				 	$hoteldetails_hotel_group_name=$hoteldetails['hotel_group_name'];
				 	$hoteldetails_img_path=$hoteldetails['img_path'];	 	
				 }

				 $hotels= array();
				 $hotels[$hotel_id] = array(
			          'amenity' => $amenity_res,         
			          'landmark_name' => $landmark_res_name,
			          'review' => $reviews,         
			          'image' => $images,
			          'hoteldetails_destination_id' => $hoteldetails_destination_id,
			          'hoteldetails_hotel_name' => $hoteldetails_hotel_name,
			          'hoteldetails_hotel_class' => $hoteldetails_hotel_class,
			          'hoteldetails_hotel_address' => $hoteldetails_hotel_address,
			          'hoteldetails_hotel_area' => $hoteldetails_hotel_area,
			          'hoteldetails_hotel_overview' => $hoteldetails_hotel_overview,
			          'hoteldetails_review_rating' => $hoteldetails_review_rating,
			          'hoteldetails_latitude' => $hoteldetails_latitude,
			          'hoteldetails_longitude' => $hoteldetails_longitude,
			          'hoteldetails_hotel_group_name' => $hoteldetails_hotel_group_name,
			          'hoteldetails_img_path' => $hoteldetails_img_path
			        );
			   	

		   		if (isset($hotels) && !empty($hotels)) 
		   		{
		   			$id_json_folder = dirname(__FILE__).'/'.$hotel_id;
				    if (!is_dir($id_json_folder)) 
				    {
				        mkdir($id_json_folder,0777);
				    }
				    if (is_dir($id_json_folder)) 
				    {
				    	$json = $id_json_folder.'/json';
				    	if (!is_dir($json)) 
				    	{
				    		mkdir($json,0777);
				    	}
				    }
				    $file = $json."/".$hotel_id.".json";
					file_put_contents($file, json_encode($hotels));
					$this->upload_json($file,$hotel_id);
		   		}   
				$i++;
			} 
				/*$msg = "<span style=color:#006621;>JSON CREATED SUCCESSFULLY FOR Hotel ID:".$hotel_id."</span><br>";
				echo $msg;*/
		}
		catch (Exception $e)
		{
			echo "JSON CREATION FAILED FOR :".$e->getMessage();

			$directoryname = dirname(__FILE__).'/log';	
			if(!is_dir($directoryname))
			{
				mkdir($directoryname,0777);
			}

			$file = $directoryname."/".date("Y-m-d").".log";
			$data = "JSON CREATION FAILED FOR :".$e->getMessage()."\n";
			file_put_contents($file, $data, FILE_APPEND | LOCK_EX);
		}
	}
}
?> 