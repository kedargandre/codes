<?php
class Station extends CI_Controller 
{
	function __construct()
	{
		parent::__construct();
		
		$this->load->model('getstation');
		
	}

    function stations()
    {
        $result['result'] = $this->getstation->stationlist();
        //echo "<pre>";print_r($result);
		$this->load->view('station_display', $result);

    }
}
?>