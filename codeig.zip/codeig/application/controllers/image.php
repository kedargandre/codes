<?php
class Image extends CI_Controller 
{
	function __construct()
	{
		parent::__construct();
	}
	public function abc()
	{
		echo "hi";
	}
	public function resize()
    {
    	$dir = "/var/www/html/kedar/codeig/common";
    	$this->load->library('image_lib');

    	$config['image_library'] 	= 'gd2';
		$config['create_thumb'] 	= TRUE;	//if we want to preserve original image make it TRUE otherwise FALSE
		$config['maintain_ratio'] 	= TRUE;
		$config['width'] 			= 1200;
		$config['height'] 			= 800;

    	if (is_dir($dir))
	    {
	     	if ($dh = opendir($dir))
	      	{
	        	while (($file = readdir($dh)) !== false)
	        	{
	        		if($file != "." && $file != "..")
	        		{
	        			echo $dir.$file."<br>";

						$config['source_image'] = $dir.$file;
						$this->image_lib->initialize($config); 

						$this->load->library('image_lib', $config);
						$this->image_lib->resize();	

						$config['new_image'] = $dir;		

						if ( ! $this->image_lib->resize())
						{
						    echo $this->image_lib->display_errors();
						}
			  		}
	            }
	            // $conn->close();
	        	closedir($dh);
	      	}
    	}
    }
}
?> 