<?php
class Form extends CI_Controller 
{
	function __construct()
	{
		parent::__construct();
		
		//$this->load->model('getstation');
		
	}

    function form_valid()
    {

		$this->load->helper(array('form', 'url'));
		$this->load->library('form_validation');

		$this->form_validation->set_rules('username', 'Username', 'callback_username_check');
		$this->form_validation->set_rules('password', 'Password', 'required');
		$this->form_validation->set_rules('passconf', 'Password Confirmation', 'required');
		$this->form_validation->set_rules('email', 'Email', 'required');

		if ($this->form_validation->run() == FALSE)
		{
			// echo "Invalid";exit;
			$this->load->view('form');
		}
		else
		{
			// echo "Valid";exit;
			$this->load->view('form_success');
		}
    }
    public function username_check($str)
	{
		if ($str == 'test')
		{
			$this->form_validation->set_message('username_check', 'The %s field can not be the word "test"');
			return FALSE;
		}
		else
		{
			return TRUE;
		}
	}
}
?>