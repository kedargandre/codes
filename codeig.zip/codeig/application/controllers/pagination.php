<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Pagination extends CI_Controller {

// Load libraries in Constructor.
function __construct() {
	parent::__construct();
	//$this->load->model('pagination_model');
	$this->load->library('pagination');
}

// Set array for PAGINATION LIBRARY, and show view data according to page.
public function page()
{
	$data =array(1,2,3,4,5,6,7,8,9,10,11,12,13,14,15);
	//$this->load->library('pagination');
	$data['config']['data'] = $data;
/*
	$config['base_url'] = 'http://localhost/kedar/codeig/index.php/pagination/page';
	$config['no_rows'] = 10;
	$config['per_page'] = 5;
	$this->pagination->initialize($config);
	$this->load->view('view', $config);*/

    $data['config']['base_url']= 'http://localhost/kedar/codeig/index.php/pagination/page';
    $data['config']['total_rows']= 10;
    $data['config']['per_page']= 2;
    // $data['current_page']=$this->page;
    $this->pagination->initialize($data['config']);
    $this->load->view('view', $data);

}
}
?>


