<?php
class Chat extends CI_Controller 
{
	function __construct()
	{
		parent::__construct();
		$this->load->model('chat_model');
	}

	public function index()
	{
		$data['chat_id'] = '1';
		$data['user_id'] = '2';

		$this->load->view('chat_view', $data);
	}
	
	public function ajax_add_chat_message()
	{
		$chat_id = $this->input->post('chat_id');
		$user_id = $this->input->post('user_id');
		$message = $this->input->post('');


		$this->chat_model->add_chat_message($chat_id, $user_id, $message);
	}
}
?> 