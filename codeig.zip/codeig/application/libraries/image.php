<?php
class Image 
{

    function __construct()
    {
        $this->ci =& get_instance();
        $this->ci->load->library('image_lib');
    }

    function resize($image_name,$image_height, $image_width) 
    {
        try 
        {
            $image_full_path = IMAGE_UPLOAD_PATH.$image_name;

            $config['image_library']    = 'gd2';
            $config['create_thumb']     = TRUE;
            $config['maintain_ratio']   = TRUE;
            $config['width']            = $image_height;
            $config['height']           = $image_width;
            $config['source_image']     = $image_full_path;

            // $this->ci->load->library('image_lib', $config);

            $this->ci->image_lib->initialize($config); 

            if (!$this->ci->image_lib->resize())
            {
                echo "<pre>";print_r('inside');exit;
                return $this->ci->image_lib->display_errors();
            }
            else
            {
                echo "<pre>";print_r('outstide');exit;
                return('1');
            }
        } 
        catch (Exception $e)
        {
            $this->mTitle = 'Message';
            $this->mViewData['error'] = $e->getMessage();
            $this->mViewFile = 'error';
        }
    }

} ?>
