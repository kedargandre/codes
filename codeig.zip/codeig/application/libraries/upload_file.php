<?php
class Upload_file 
{

    function __construct()
    {
        $this->ci =& get_instance();
        $this->ci->load->library('upload');
    }

    function upload_pdf($name_of_file) 
    {
        try 
        {
            $config['upload_path']      = DOCUMENT_UPLOAD_PATH;
            $config['allowed_types']    = 'pdf';
            $config['max_size']         = '2000';
            $config['remove_spaces']    = true;
            $config['overwrite']        = false;
            $config['encrypt_name']     = true;
            $config['max_width']        = '';
            $config['max_height']       = '';
                     
            $this->ci->upload->initialize($config);

            if (!$this->ci->upload->do_upload($name_of_file))
            {
                return $this->ci->upload->display_errors();
            }
            else
            {
                return('1');
            }
        } 
        catch (Exception $e)
        {
            $this->mTitle = 'Message';
            $this->mViewData['error'] = $e->getMessage();
            $this->mViewFile = 'error';
        }
    }

    function upload_image() 
    {
        try 
        {
            $config['upload_path']      = IMAGE_UPLOAD_PATH;
            $config['allowed_types']    = 'jpg|jpeg';
            $config['max_size']         = '2000';
            $config['remove_spaces']    = true;
            $config['overwrite']        = false;
            $config['encrypt_name']     = true;
            $config['max_width']        = '';
            $config['max_height']       = '';
                     
            $this->ci->upload->initialize($config);

            if (!$this->ci->upload->do_upload())
            {
                return $this->ci->upload->display_errors();
            }
            else
            {
                return('1');
            }
        } 
        catch (Exception $e)
        {
            $this->mTitle = 'Message';
            $this->mViewData['error'] = $e->getMessage();
            $this->mViewFile = 'error';
        }
    }

} ?>
