<?php 

class DbTable
{
    //Table Constants

    const TABLE_CONTACT_US              = 'tbl_contact_us';

    const TABLE_REGISTRATION_REQUEST    = 'tbl_registration_request';
}
