<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Chat_model extends CI_Model 
{
	function __construct() 
	{
		parent::__construct();
		$this->db_eq_page 	= $this->load->database('default',true);
	}
	
	function add_chat_message($chat_id, $user_id, $message)
	{
		$save_data =  array(
			'chat_id' 		=> $chat_id,
			'user_id' 		=> $user_id,
			'chat_message'	=> $message,
		);
		
		$this->db_eq_page->insert('tbl_chat_messages', $save_data);
	}

}
?>


