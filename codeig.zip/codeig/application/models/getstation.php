<?php
class Getstation extends CI_Model 
{

    function stationlist()
    {
    	$this->load->database();
    	//$sql = "SELECT station_name FROM tbl_stationlist WHERE id = 1";
    	//return("hello");
    	$query = $this->db->query("SELECT station_name FROM tbl_stationlist");
    	/*foreach ($query->result() as $row)
		{
			$row;
		}*/
		//$query->result();
		return $query->result_array();

    }
}
?>