<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/*
| -------------------------------------------------------------------
| EMAIL CONFING
| -------------------------------------------------------------------
| Configuration of outgoing mail server.
| */

// Mandrill
$config['protocol'] = 'smtp';
$config['smtp_host'] = 'ssl://smtp.googlemail.com';
$config['smtp_port'] = '465';
$config['smtp_timeout'] = '30';
$config['smtp_user'] = 'email';
$config['smtp_pass'] = 'password';


$config['charset'] = 'utf-8';
$config['mailtype'] = 'html';
$config['wordwrap'] = TRUE;
$config['newline'] = "\r\n";

// custom values from CodeIgniter Bootstrap
$config['from_email'] = "info@flexgo.com";
$config['from_name'] = "FlexGo";
$config['subject_prefix'] = "";

/* End of file email.php */
/* Location: ./system/application/config/email.php */